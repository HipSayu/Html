# Frame hover effect with one element

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/JjLVLPL](https://codepen.io/t_afif/pen/JjLVLPL).

CSS Tip!
https://twitter.com/ChallengesCss/status/1562396342877667328